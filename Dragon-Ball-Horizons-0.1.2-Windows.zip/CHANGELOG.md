# 0.1.2 — exploration encounters and native training points

- Discover Red Ribbon battle towers in newly generated Earth and Overworld terrain, and Frieza Force landing craft on new Namek and Planet Vegeta terrain.
- Fight two guards and a commander. Participating nearby players with native characters each earn 150 training points at towers or 350 at ships. Encounters reset after 20 minutes of world time.
- Generated sites and active rounds persist across server restarts. Old chunks and nearby named landmarks stay unchanged.
- Upgrade an existing Prism instance by disabling the old Dragon Ball Horizons addon and adding the 0.1.2 addon; keep DragonMine Z enabled and keep the same world. Explore new terrain to find sites.

# 0.1.1 — keyboard and mouse conflict fix

- F remains flight; offhand swap moves to O.
- G remains transformation; Curios accessories move to I.
- Z remains lock-on; enlarged minimap moves to Backslash.
- R remains dash; Oculus shader reload moves to F9. Shader selection moves from O to F8.
- H remains Instant Transmission; spacepod menu moves to N.
- Disable eight default Inventory Profiles in-world R chords, including R+C, R+Z and R+X. Inventory-screen R sorting and custom shortcuts remain available.
- Automatically repair conflicting defaults once on startup. Back up options.txt and Inventory Profiles configuration under config/dbh-control-backups. Preserve customized mappings and skip occupied destination keys.
- Add Repair key conflicts to the J guide and title-screen Horizons Guide for players who later reset their controls.

Existing players: close Minecraft, move dragon-ball-horizons-0.1.0.jar out of your instance's mods folder, and add dragon-ball-horizons-0.1.1.jar. Keep DragonMine Z, other mods, and the existing instance. Do not install both Horizons versions together. The next launch applies the repair; no world reset is needed.

Verified in the locked production client: six native key remaps, eight IPN bindings, unchanged combat keys and GUI sorting, preservation of custom bindings, and idempotent repeated repair. The Forge integration suite also passed all 15 required tests during this update. A complete Windows gameplay and multiplayer acceptance pass remains outstanding.
